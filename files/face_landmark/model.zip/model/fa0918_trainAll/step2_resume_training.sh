#!/usr/bin/env sh

./build/tools/caffe train --solver=fa0915-2/step2_solver.prototxt -gpu 1,2,3,5 --snapshot=fa0915-2/step2__iter_8140.solverstate


