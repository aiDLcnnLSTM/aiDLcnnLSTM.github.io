#!/usr/bin/env sh

./build/tools/caffe train --solver=fa0914/solver_0914_fix.prototxt --snapshot=fa0914/0914_iter_1000.solverstate -gpu 1,2,3,4,5,14


