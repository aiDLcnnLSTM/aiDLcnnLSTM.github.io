#!/usr/bin/env sh

./build/tools/caffe train --solver=fa0918_trainAll/step1_solver.prototxt -gpu 15

