#!/usr/bin/env sh

./build/tools/caffe train --solver=fa0918_trainAll/step2_solver.prototxt -gpu 1,2,3,15 --snapshot=fa0918_trainAll/step11_iter_9500.solverstate
