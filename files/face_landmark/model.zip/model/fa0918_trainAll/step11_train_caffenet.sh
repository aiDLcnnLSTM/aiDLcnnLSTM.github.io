#!/usr/bin/env sh

./build/tools/caffe train --solver=fa0918_trainAll/step11_solver.prototxt -gpu 13,14 --snapshot=fa0918_trainAll/step1_iter_1000.solverstate

