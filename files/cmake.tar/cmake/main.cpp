#include <iostream>

using namespace std;

#include "config.h"

#ifdef USE_MYADD
#include <myadd/my_add.h>
#endif


int main(int argc, char* argv[])
{

	cout << "version " << DEMO_VERSION_MAJOR << "." << DEMO_VERSION_MINOR << endl;
	cout << "OK  "<< endl;
	cout << "Useage: ./Demo4 a b" << endl;
	int a,b;
	
	//while(1)
	{
		cin>>a;
		cin>>b;
		#ifdef USE_MYADD
		cout << a<< " + " << b << " = "<< my_add(a,b) << endl;
		#else
		cout << "not use dll" << endl;
		#endif
	}	

	return 0;

}
